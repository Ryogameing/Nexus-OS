# Building the development live ISO

NexusOS uses Debian `live-build` as its only canonical image-construction path.

## Host requirements

Use Debian 12 or a compatible Ubuntu host with:

```bash
sudo apt update
sudo apt install live-build xorriso debootstrap squashfs-tools \
  debian-archive-keyring grub-pc-bin grub-efi-amd64-bin mtools \
  qemu-system-x86 ovmf
```

The live-build profile pins Debian Bookworm bootstrap, chroot, binary, and
security mirrors explicitly so Ubuntu host defaults cannot redirect the build
to Ubuntu archives.

## Build

```bash
sudo ./scripts/build-iso.sh desktop
```

The script stages the canonical shell and generated release metadata, then writes an ISO and SHA-256 file to `dist/`. ISO generation requires root privileges inside `live-build`.

Handheld, console, and arm64 images are not release-supported yet.

## QEMU boot gates

```bash
sudo ./scripts/test-iso-qemu.sh dist/*.iso bios
sudo ./scripts/test-iso-qemu.sh dist/*.iso uefi
```

A serial marker proves that systemd reached the multi-user target. It does not replace graphical-session, controller, audio, network, installer, or hardware testing.
