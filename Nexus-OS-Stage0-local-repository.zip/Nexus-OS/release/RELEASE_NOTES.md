# NexusOS 3.0.0-alpha5 — Nebula Ascension

These notes describe the planned first prerelease from the canonical repository. They must be finalized only after the public workflow builds and verifies the release artifacts.

## Added

- canonical repository structure based on the alpha4 scaffold
- single-source version generation
- active Release-mode tests
- repository hygiene and insecure-default checks
- pinned, least-privilege GitHub workflows
- desktop-amd64 BIOS and UEFI boot gates

## Status

This remains an alpha. Do not publish these notes until the tagged workflow completes source validation, live-image construction, ISO inspection, BIOS boot, UEFI boot, checksums, and prerelease publication.
