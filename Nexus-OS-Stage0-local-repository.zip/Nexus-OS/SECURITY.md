# Security policy

## Supported versions

NexusOS is pre-release software. Only the latest commit on `main` and the newest published prerelease are considered for security fixes.

## Reporting a vulnerability

Do not open a public issue for vulnerabilities involving privilege escalation, boot security, installer data loss, update signing, secrets, or remote code execution.

Use GitHub's private vulnerability-reporting feature for `Ryogameing/Nexus-OS`. Include the affected version, reproduction steps, impact, and a minimal proof of concept. Remove personal data, credentials, proprietary games, ROMs, and console BIOS files.

## Release security baseline

NexusOS releases must not contain:

- known default credentials
- blanket passwordless administrator access
- private signing keys or access tokens
- proprietary console BIOS files, ROMs, or games
- unreviewed destructive disk operations

Checksums alone do not establish authenticity. Production releases require signed tags, signed artifacts, provenance, and a software bill of materials.
