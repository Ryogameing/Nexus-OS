# nexusos-core package status

This directory is reserved for the canonical Debian package that will install the NexusOS C++ utilities, profiles, defaults, shell assets, and services into the live image.

The earlier alpha package contained only an incomplete `.install` manifest, so it has been removed. A package must not be enabled in the ISO until its `debian/control`, build rules, install manifest, copyright metadata, and CI installation test are complete.
