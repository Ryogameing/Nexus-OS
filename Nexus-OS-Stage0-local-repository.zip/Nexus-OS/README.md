# NexusOS

NexusOS is an experimental, gaming-focused Linux distribution. This repository is the canonical development tree for the core utilities, graphical shell, Debian live-image configuration, installer planning, recovery diagnostics, tests, and release automation.

## Project status

The current version is recorded in [`VERSION`](VERSION). It is a development alpha, not a production operating system.

Verified source-level capabilities:

- C++20 core and command-line development utilities
- local browser-based shell prototype
- persistent development settings and library scanning
- read-only installer planning
- recovery diagnostics
- canonical Debian `live-build` configuration
- CI, repository-hygiene checks, and BIOS/UEFI boot-test definitions

Not yet release-complete:

- a publicly verified bootable ISO
- game launching and emulator integration
- destructive disk installation
- signed updates and rollback
- production recovery actions
- supported hardware certification

## Build and test

Requirements:

- CMake 3.20 or newer
- a C++20 compiler
- Python 3
- Bash and `wget`

```bash
./scripts/validate-release.sh
```

This builds the Release configuration with warnings treated as errors, runs tests whose checks remain active under `NDEBUG`, validates scripts and metadata, scans for known insecure defaults, and smoke-tests the web shell.

## Run the graphical shell

```bash
./scripts/generate-release-metadata.py shell/web/release.json
python3 scripts/nexus-shell-web.py --root shell/web
```

Then open `http://127.0.0.1:8765`. Remove the generated `shell/web/release.json` before committing.

## Build a development ISO

The first verified release target is desktop amd64. Handheld and console profiles remain design scaffolds.

Use an internet-connected Debian or Ubuntu build host with the dependencies in [`docs/building/iso.md`](docs/building/iso.md):

```bash
sudo ./scripts/build-iso.sh desktop
```

An ISO is not considered verified until both BIOS and UEFI QEMU boot gates pass and the graphical session has been checked. See [`docs/release/iso-status.md`](docs/release/iso-status.md).

## Repository layout

- `src`, `include`, `tests`: C++ core, apps, and active Release-mode tests
- `shell/web`: canonical graphical shell source
- `distro/live-build`: canonical Debian image configuration
- `distro/profiles`: future edition overlays; desktop is the first release target
- `installer`, `recovery`: safe development implementations and status
- `scripts`: build, validation, packaging, and runtime tools
- `docs`: architecture, build, release, security, legal, and hardware documentation
- `.github`: pinned CI, ISO, security, and release workflows

## Safety

The included installer only creates a plan. It does not partition, format, or overwrite disks. NexusOS does not include console BIOS files, ROMs, games, product keys, or other proprietary content.

Report vulnerabilities using [`SECURITY.md`](SECURITY.md), not a public issue.

## License

NexusOS source code is licensed under the MIT License. Distributed operating-system images also contain third-party packages under their respective licenses.
