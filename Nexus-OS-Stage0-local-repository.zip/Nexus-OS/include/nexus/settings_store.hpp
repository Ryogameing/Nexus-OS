#pragma once
#include <map>
#include <string>

namespace nexus {
class SettingsStore {
public:
    explicit SettingsStore(std::string path);
    bool load();
    bool save() const;
    std::string get(const std::string& key, const std::string& fallback = "") const;
    void set(std::string key, std::string value);
    const std::map<std::string, std::string>& values() const;
private:
    std::string path_;
    std::map<std::string, std::string> values_;
};
}
