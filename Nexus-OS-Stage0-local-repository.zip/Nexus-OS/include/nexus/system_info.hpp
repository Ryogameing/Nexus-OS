#pragma once
#include <string>

namespace nexus {
struct SystemInfo {
    std::string version;
    std::string codename;
    std::string profile;
};

SystemInfo current_system_info();
}
