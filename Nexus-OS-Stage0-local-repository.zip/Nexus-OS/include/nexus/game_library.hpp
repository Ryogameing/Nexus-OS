#pragma once
#include <string>
#include <vector>

namespace nexus {
struct GameEntry { std::string title; std::string path; std::string type; };
std::vector<GameEntry> scan_game_library(const std::string& root);
}
