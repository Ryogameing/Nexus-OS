#pragma once
#include <string>

namespace nexus {
struct InstallerPlan {
    std::string target;
    std::string profile;
    bool erase_disk{false};
    bool valid{false};
    std::string warning;
};
InstallerPlan make_installer_plan(std::string target, std::string profile, bool erase_disk);
std::string describe_installer_plan(const InstallerPlan& plan);
}
