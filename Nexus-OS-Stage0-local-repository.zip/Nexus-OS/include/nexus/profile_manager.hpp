#pragma once
#include <string>

namespace nexus {
class ProfileManager {
public:
    explicit ProfileManager(std::string profile);
    const std::string& profile() const noexcept;
    bool is_supported() const noexcept;
private:
    std::string profile_;
};
}
