const views=[...document.querySelectorAll('.view')];
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{views.forEach(v=>v.classList.toggle('active',v.id===b.dataset.view));});
const clock=document.querySelector('#clock');
const save=document.querySelector('#save'),saved=document.querySelector('#saved'),status=document.querySelector('#status');
const games=document.querySelector('#games'),plan=document.querySelector('#plan'),installPlan=document.querySelector('#installPlan');
setInterval(()=>{clock.textContent=new Date().toLocaleString();},1000);
const profile=document.querySelector('#profile'),session=document.querySelector('#session');
profile.value=localStorage.profile||'desktop'; session.value=localStorage.session||'desktop';
save.onclick=()=>{localStorage.profile=profile.value;localStorage.session=session.value;saved.textContent='Settings saved for this user.'};
fetch('release.json')
  .then(response=>response.ok?response.json():Promise.reject(new Error('release metadata unavailable')))
  .then(release=>{status.textContent=`Profile: ${profile.value}\nSession: ${session.value}\nShell: integrated web UI\nRelease: ${release.version}\nChannel: ${release.channel}`;})
  .catch(()=>{status.textContent=`Profile: ${profile.value}\nSession: ${session.value}\nShell: integrated web UI\nRelease: development tree`;});
const sample=['Steam','Nexus Settings','Installer Preview','Recovery Diagnostics'];
games.innerHTML=sample.map(x=>`<article><h3>${x}</h3><p>Integration status: development scaffold.</p><button disabled>Not available yet</button></article>`).join('');
plan.onclick=()=>installPlan.textContent='1. Verify target disk\n2. Create EFI and system partitions\n3. Copy live system\n4. Install bootloader\n5. Create user\n\nALPHA SAFETY: execution disabled.';
