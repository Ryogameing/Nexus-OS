#pragma once

#include <iostream>
#include <string_view>

namespace nexus::test {
inline int failures = 0;

inline void check(bool condition, std::string_view expression, std::string_view file, int line) {
    if (condition) {
        return;
    }
    ++failures;
    std::cerr << file << ':' << line << ": check failed: " << expression << '\n';
}

inline int finish() {
    if (failures == 0) {
        return 0;
    }
    std::cerr << failures << " test check(s) failed\n";
    return 1;
}
}

#define NEXUS_CHECK(expression) \
    ::nexus::test::check(static_cast<bool>(expression), #expression, __FILE__, __LINE__)
