#include "nexus/game_library.hpp"
#include "nexus/installer_plan.hpp"
#include "nexus/settings_store.hpp"
#include "test_support.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>

int main() {
    namespace fs = std::filesystem;
    const auto unique = std::chrono::steady_clock::now().time_since_epoch().count();
    const fs::path root = fs::temp_directory_path() / ("nexus-alpha-tests-" + std::to_string(unique));
    fs::remove_all(root);
    fs::create_directories(root / "games");
    std::ofstream(root / "games" / "Example.desktop") << "[Desktop Entry]\n";
    std::ofstream(root / "games" / "ignore.txt") << "no";

    nexus::SettingsStore settings((root / "settings.conf").string());
    settings.set("profile", "handheld");
    NEXUS_CHECK(settings.save());
    nexus::SettingsStore loaded((root / "settings.conf").string());
    NEXUS_CHECK(loaded.load());
    NEXUS_CHECK(loaded.get("profile") == "handheld");

    const auto games = nexus::scan_game_library((root / "games").string());
    NEXUS_CHECK(games.size() == 1);
    NEXUS_CHECK(!games.empty() && games.front().title == "Example");

    const auto safe = nexus::make_installer_plan("/dev/test", "desktop", false);
    NEXUS_CHECK(safe.valid && !safe.erase_disk);
    const auto invalid = nexus::make_installer_plan("", "desktop", false);
    NEXUS_CHECK(!invalid.valid);
    fs::remove_all(root);
    return nexus::test::finish();
}
