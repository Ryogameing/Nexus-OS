#include "nexus/profile_manager.hpp"
#include "nexus/system_info.hpp"
#include "test_support.hpp"

int main() {
    const auto info = nexus::current_system_info();
    NEXUS_CHECK(info.version == "3.0.0-alpha5-dev");
    NEXUS_CHECK(info.codename == "Nebula Ascension");

    NEXUS_CHECK(nexus::ProfileManager("desktop").is_supported());
    NEXUS_CHECK(nexus::ProfileManager("handheld").is_supported());
    NEXUS_CHECK(!nexus::ProfileManager("unknown").is_supported());
    return nexus::test::finish();
}
