# Recovery status

Planned recovery capabilities include filesystem checks, bootloader repair, configuration reset, log export, and rollback. This directory intentionally contains documentation only; destructive recovery commands are not enabled yet.
