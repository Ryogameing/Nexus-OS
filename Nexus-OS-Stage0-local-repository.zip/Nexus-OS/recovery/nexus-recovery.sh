#!/bin/sh
set -eu
echo 'NexusOS Recovery Diagnostics'
uname -a
printf '\nStorage:\n'; lsblk 2>/dev/null || true
printf '\nMemory:\n'; free -h 2>/dev/null || true
printf '\nNetwork:\n'; ip -brief address 2>/dev/null || true
