# Contributing to NexusOS

NexusOS is an early-alpha operating-system project. Keep changes focused, reviewable, and honest about what has been tested.

## Development workflow

1. Create a branch from `main`.
2. Make one coherent change.
3. Run `./scripts/validate-release.sh`.
4. Run ISO or hardware checks when changing boot, image, installer, recovery, input, graphics, or storage behavior.
5. Open a pull request using the repository template.

Pull requests must not include generated build directories, ISOs, chroots, caches, credentials, signing keys, ROMs, console BIOS files, games, or proprietary firmware.

## Code expectations

- C++ must compile as C++20 with warnings treated as errors.
- Tests must perform active checks in Release builds and when `NDEBUG` is defined.
- Shell scripts must use strict error handling where Bash is required.
- Destructive behavior requires explicit target validation, user confirmation, rollback planning, and dedicated tests.
- Documentation must distinguish implemented, experimentally verified, and planned behavior.

## Commit and review policy

Use short imperative commit messages. The protected `main` branch should require CI, a pull request, and review for release-sensitive paths. Do not force-push release tags.
