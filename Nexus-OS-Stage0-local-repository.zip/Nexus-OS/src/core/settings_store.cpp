#include "nexus/settings_store.hpp"
#include <filesystem>
#include <fstream>

namespace nexus {
SettingsStore::SettingsStore(std::string path) : path_(std::move(path)) {}

bool SettingsStore::load() {
    values_.clear();
    std::ifstream input(path_);
    if (!input) return false;
    std::string line;
    while (std::getline(input, line)) {
        if (line.empty() || line[0] == '#') continue;
        const auto pos = line.find('=');
        if (pos == std::string::npos) continue;
        values_[line.substr(0, pos)] = line.substr(pos + 1);
    }
    return true;
}

bool SettingsStore::save() const {
    const std::filesystem::path path(path_);
    if (path.has_parent_path()) std::filesystem::create_directories(path.parent_path());
    std::ofstream output(path_);
    if (!output) return false;
    output << "# NexusOS settings\n";
    for (const auto& [key, value] : values_) output << key << '=' << value << '\n';
    return true;
}

std::string SettingsStore::get(const std::string& key, const std::string& fallback) const {
    const auto it = values_.find(key);
    return it == values_.end() ? fallback : it->second;
}

void SettingsStore::set(std::string key, std::string value) {
    values_[std::move(key)] = std::move(value);
}

const std::map<std::string, std::string>& SettingsStore::values() const { return values_; }
}
