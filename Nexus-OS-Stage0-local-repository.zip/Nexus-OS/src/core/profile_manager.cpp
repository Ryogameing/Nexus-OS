#include "nexus/profile_manager.hpp"
#include <array>
#include <algorithm>
#include <utility>

namespace nexus {
ProfileManager::ProfileManager(std::string profile) : profile_(std::move(profile)) {}

const std::string& ProfileManager::profile() const noexcept { return profile_; }

bool ProfileManager::is_supported() const noexcept {
    static constexpr std::array<const char*, 3> supported = {
        "desktop", "handheld", "console"
    };
    return std::any_of(supported.begin(), supported.end(), [this](const char* value) {
        return profile_ == value;
    });
}
}
