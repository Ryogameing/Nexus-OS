#include "nexus/system_info.hpp"
#include "nexus/version.hpp"

namespace nexus {
SystemInfo current_system_info() {
    return {std::string(build::version), std::string(build::codename), "desktop"};
}
}
