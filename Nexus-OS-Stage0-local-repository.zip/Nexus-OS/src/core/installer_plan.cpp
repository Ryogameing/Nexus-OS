#include "nexus/installer_plan.hpp"
#include <set>
#include <sstream>

namespace nexus {
InstallerPlan make_installer_plan(std::string target, std::string profile, bool erase_disk) {
    const std::set<std::string> profiles{"desktop", "handheld", "console"};
    InstallerPlan plan{std::move(target), std::move(profile), erase_disk, false, ""};
    if (plan.target.empty()) { plan.warning = "No installation target was selected."; return plan; }
    if (!profiles.contains(plan.profile)) { plan.warning = "Unknown edition profile."; return plan; }
    plan.valid = true;
    plan.warning = erase_disk
        ? "DESTRUCTIVE PLAN: the selected target would be erased. Preview only; no disk changes are implemented."
        : "Non-destructive preview. Manual partition selection would be required.";
    return plan;
}

std::string describe_installer_plan(const InstallerPlan& plan) {
    std::ostringstream out;
    out << "Target: " << (plan.target.empty() ? "(none)" : plan.target) << '\n'
        << "Profile: " << plan.profile << '\n'
        << "Erase disk: " << (plan.erase_disk ? "yes" : "no") << '\n'
        << "Valid: " << (plan.valid ? "yes" : "no") << '\n'
        << "Notice: " << plan.warning;
    return out.str();
}
}
