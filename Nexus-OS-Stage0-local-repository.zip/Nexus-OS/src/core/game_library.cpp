#include "nexus/game_library.hpp"
#include <algorithm>
#include <filesystem>
#include <set>

namespace nexus {
std::vector<GameEntry> scan_game_library(const std::string& root) {
    namespace fs = std::filesystem;
    const std::set<std::string> allowed{".desktop", ".appimage", ".sh", ".iso", ".chd"};
    std::vector<GameEntry> games;
    std::error_code ec;
    if (!fs::exists(root, ec)) return games;
    for (fs::recursive_directory_iterator it(root, fs::directory_options::skip_permission_denied, ec), end; it != end; it.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        if (!it->is_regular_file(ec)) continue;
        std::string ext = it->path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
        if (!allowed.contains(ext)) continue;
        games.push_back({it->path().stem().string(), it->path().string(), ext.substr(1)});
    }
    std::sort(games.begin(), games.end(), [](const GameEntry& a, const GameEntry& b){ return a.title < b.title; });
    return games;
}
}
