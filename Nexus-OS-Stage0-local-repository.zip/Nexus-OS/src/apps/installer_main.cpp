#include "nexus/installer_plan.hpp"
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "Usage: nexus-installer-plan TARGET PROFILE [--erase-disk]\n";
        return 2;
    }
    const bool erase = argc > 3 && std::string(argv[3]) == "--erase-disk";
    const auto plan = nexus::make_installer_plan(argv[1], argv[2], erase);
    std::cout << "NexusOS installer preview\n" << nexus::describe_installer_plan(plan) << '\n';
    return plan.valid ? 0 : 1;
}
