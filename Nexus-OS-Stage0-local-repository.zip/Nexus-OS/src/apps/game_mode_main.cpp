#include "nexus/game_library.hpp"
#include <cstdlib>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    const char* home = std::getenv("HOME");
    std::string root = argc > 1 ? argv[1] : std::string(home ? home : ".") + "/Games";
    const auto games = nexus::scan_game_library(root);
    std::cout << "Nexus Game Mode library: " << root << "\n";
    if (games.empty()) { std::cout << "No supported launch entries found.\n"; return 0; }
    for (std::size_t i = 0; i < games.size(); ++i)
        std::cout << i + 1 << ". " << games[i].title << " [" << games[i].type << "]\n   " << games[i].path << '\n';
    std::cout << "\nLaunching is intentionally disabled in this alpha prototype.\n";
}
