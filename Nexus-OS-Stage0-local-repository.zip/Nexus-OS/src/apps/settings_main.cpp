#include "nexus/settings_store.hpp"
#include <cstdlib>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    const char* home = std::getenv("HOME");
    std::string path = std::string(home ? home : ".") + "/.config/nexusos/settings.conf";
    nexus::SettingsStore store(path);
    store.load();
    if (argc == 1 || std::string(argv[1]) == "list") {
        for (const auto& [key, value] : store.values()) std::cout << key << '=' << value << '\n';
        return 0;
    }
    if (argc == 4 && std::string(argv[1]) == "set") {
        store.set(argv[2], argv[3]);
        if (!store.save()) { std::cerr << "Unable to save " << path << '\n'; return 1; }
        std::cout << "Saved " << argv[2] << '=' << argv[3] << '\n';
        return 0;
    }
    std::cerr << "Usage: nexus-settings [list | set KEY VALUE]\n";
    return 2;
}
