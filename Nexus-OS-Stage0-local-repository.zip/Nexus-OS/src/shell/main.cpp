#include "nexus/game_library.hpp"
#include "nexus/profile_manager.hpp"
#include "nexus/settings_store.hpp"
#include "nexus/system_info.hpp"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>

namespace {
void help() {
    std::cout << "Commands:\n"
              << "  help                     Show commands\n"
              << "  status                   Show system information\n"
              << "  profile <name>           Select desktop/handheld/console\n"
              << "  settings                 List saved settings\n"
              << "  set <key> <value>        Save a setting\n"
              << "  games [directory]        Scan a game library\n"
              << "  game-mode                Switch the session preference to game mode\n"
              << "  desktop-mode             Switch the session preference to desktop mode\n"
              << "  exit                     Quit\n";
}
}

int main(int argc, char** argv) {
    const char* home = std::getenv("HOME");
    nexus::SettingsStore settings(std::string(home ? home : ".") + "/.config/nexusos/settings.conf");
    settings.load();
    std::string profile = settings.get("profile", argc > 1 ? argv[1] : "desktop");
    const auto system = nexus::current_system_info();

    std::cout << "Nexus Shell " << system.version << " terminal prototype\n"
              << "Profile: " << profile << " | type 'help'\n";
    std::string line;
    while (std::cout << "nexus> " && std::getline(std::cin, line)) {
        std::istringstream in(line);
        std::string command;
        in >> command;
        if (command.empty()) continue;
        if (command == "exit" || command == "quit") break;
        if (command == "help") { help(); continue; }
        if (command == "status") { const auto info = nexus::current_system_info(); std::cout << "NexusOS " << info.version << " (" << info.codename << ")\nProfile: " << profile << '\n'; continue; }
        if (command == "profile") {
            std::string requested; in >> requested;
            if (!nexus::ProfileManager(requested).is_supported()) { std::cout << "Unsupported profile.\n"; continue; }
            profile = requested; settings.set("profile", profile); settings.save();
            std::cout << "Profile changed to " << profile << ".\n"; continue;
        }
        if (command == "settings") {
            for (const auto& [key, value] : settings.values()) std::cout << key << '=' << value << '\n';
            continue;
        }
        if (command == "set") {
            std::string key, value; in >> key; std::getline(in >> std::ws, value);
            if (key.empty() || value.empty()) { std::cout << "Usage: set KEY VALUE\n"; continue; }
            settings.set(key, value); settings.save(); std::cout << "Saved.\n"; continue;
        }
        if (command == "games") {
            std::string path; std::getline(in >> std::ws, path);
            if (path.empty()) path = std::string(home ? home : ".") + "/Games";
            const auto games = nexus::scan_game_library(path);
            std::cout << games.size() << " entries found.\n";
            for (const auto& game : games) std::cout << "- " << game.title << " [" << game.type << "]\n";
            continue;
        }
        if (command == "game-mode" || command == "desktop-mode") {
            const std::string mode = command == "game-mode" ? "game" : "desktop";
            settings.set("session.mode", mode); settings.save(); std::cout << "Preferred session mode: " << mode << '\n'; continue;
        }
        std::cout << "Unknown command. Type 'help'.\n";
    }
    return 0;
}
