## Summary

Describe the user-visible or developer-visible change.

## Validation

- [ ] `./scripts/validate-release.sh`
- [ ] Relevant ISO or hardware checks, when applicable

## Safety and release impact

- [ ] No credentials, ROMs, console BIOS files, signing keys, or generated build artifacts are included.
- [ ] Destructive installer, recovery, or storage behavior is absent or explicitly reviewed.
- [ ] Documentation and release notes are updated when behavior changes.
