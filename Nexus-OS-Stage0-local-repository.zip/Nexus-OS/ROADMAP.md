# NexusOS roadmap

## Stage 0 — Canonical repository

- [x] Establish the alpha5 development tree from the alpha4 scaffold
- [x] Consolidate around one Debian live-build path
- [x] Centralize version generation
- [x] Keep test checks active in Release builds
- [x] Add pinned, least-privilege CI and release workflows
- [x] Block known insecure defaults and generated artifacts
- [x] Add contribution, security, legal, and release policies
- [ ] Publish the initial repository commit
- [ ] Enable branch protection and private vulnerability reporting

## Stage 1 — Verified desktop ISO

- [ ] Create and install the `nexusos-core` Debian package
- [ ] Lock or record package inputs for reproducible builds
- [ ] Build desktop amd64 in the public GitHub workflow
- [ ] Pass BIOS and UEFI boot gates
- [ ] Verify the graphical Nexus session after boot
- [ ] Generate signatures, SBOM, provenance, package manifest, and validation logs
- [ ] Publish `v3.0.0-alpha5` as a prerelease

## Stage 2 — Functional gaming preview

- [ ] Replace sample UI data with a real backend
- [ ] Add safe game and application launch descriptors
- [ ] Integrate Steam and an initial documented emulator set
- [ ] Add controller navigation, mapping, disconnect, and reconnect handling
- [ ] Add audio, display, GPU, and performance controls
- [ ] Implement real desktop, handheld, and console overlays

## Stage 3 — Installation, recovery, and updates

- [ ] Implement and validate a guided UEFI/GPT installer
- [ ] Add encryption and first-boot user provisioning
- [ ] Add signed updates, compatibility checks, rollback, and recovery media
- [ ] Validate upgrade and rollback from the previous release

## Stage 4 — Stable release

- [ ] Complete security, licensing, hardware, performance, and soak-test gates
- [ ] Publish the supported hardware matrix and known limitations
- [ ] Promote the fully tested release candidate to `v3.0.0`
