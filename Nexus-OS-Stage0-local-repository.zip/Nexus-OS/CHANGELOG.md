# Changelog

All notable NexusOS changes are documented here. The project follows semantic versioning once a release is published from the canonical repository.

## Unreleased — 3.0.0-alpha5-dev

### Added

- Canonical repository structure based on the alpha4 development scaffold
- centralized version generation from `VERSION`
- tests that remain active in Release builds
- repository hygiene and insecure-default scanning
- pinned GitHub Actions and least-privilege workflows
- BIOS and UEFI development-ISO test definitions
- contribution, security, issue, and release policies

### Changed

- consolidated the release path around Debian `live-build`
- staged shell and release metadata into images from canonical source at build time
- limited the first verified ISO target to desktop amd64

### Removed

- duplicated live-image copies of shell source and release metadata
- active arm64 claims without an arm64 image pipeline
- incomplete Debian install manifest that could not build a package
