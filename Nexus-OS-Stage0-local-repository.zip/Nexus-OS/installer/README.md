# Installer status

The ISO uses Debian Installer in live mode as a development foundation. NexusOS does not yet ship a custom disk installer. Never advertise unattended installation until partitioning, encryption, rollback, and recovery have been tested on disposable hardware and virtual machines.
