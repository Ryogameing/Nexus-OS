#!/bin/sh
set -eu
cat <<'PLAN'
NexusOS installation plan (read-only alpha)
- UEFI boot required
- 1 GiB EFI partition recommended
- 32 GiB minimum system partition
- Existing disks are never modified by this script
PLAN
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS 2>/dev/null || true
