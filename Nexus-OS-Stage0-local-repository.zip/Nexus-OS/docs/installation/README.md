# Installation status

NexusOS does not yet provide a production disk installer. The current installer code creates a read-only plan and does not partition, format, mount, copy files, create users, or install a bootloader.

Installation work must add target-disk identity checks, explicit destructive confirmation, UEFI/GPT tests, encryption, interruption recovery, rollback, and disposable-VM validation before it can be enabled.
