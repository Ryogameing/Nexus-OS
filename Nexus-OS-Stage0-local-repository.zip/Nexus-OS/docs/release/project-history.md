# Project package history

Before the canonical repository was established, NexusOS was developed through a series of generated ZIP packages:

- v0.3 and 1.0 foundation scaffolds
- 2.0 Nebula packages labeled stable or GitHub-ready
- 2.5 and 2.5-dev2 packages
- 3.0.0 alpha1 through alpha4 packages
- separate bootable-ISO and Windows 11/WSL2 builder toolkits

The package names reflected intended milestones, not verified public releases. The official GitHub repository remained empty, and no saved evidence established a production ISO, installation, update, rollback, or hardware result.

The canonical repository starts from the 3.0.0-alpha4 source scaffold because it contains the most complete and honest development baseline. Stage 0 advances the tree to `3.0.0-alpha5-dev`.

The separate custom builder is retired from the release path because it did not build the same product tree and contained a known default account plus unrestricted passwordless sudo. Future Windows tooling may wrap the canonical Debian live-build workflow, but it must not implement a second operating-system image.
