# Required GitHub repository settings

Apply these settings after the initial source import:

- protect `main`
- require pull requests before merging
- require the `CI / build-test` and `Security Baseline / repository-hygiene` checks
- require the branch to be current before merging
- block force pushes and branch deletion
- restrict release-tag creation
- enable private vulnerability reporting
- enable secret scanning and push protection where available
- use squash merging for focused project history

Repository settings are not stored in this source package and must be verified after publication.
