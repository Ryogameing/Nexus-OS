# ISO build status

The repository contains a canonical Debian live-build configuration for a desktop-amd64 development image. Other profiles remain roadmap scaffolds.

## Verified at Stage 0

- Project C++ targets compile.
- Automated unit tests pass.
- Test checks remain active with `NDEBUG`.
- Shell scripts pass syntax validation.
- Web-shell smoke testing passes.
- Repository security and hygiene validation is defined.
- BIOS and UEFI CI gates are defined.

## Not yet verified

- No canonical ISO has completed the public GitHub workflow.
- No BIOS or UEFI boot log has been published.
- The graphical session has not been validated inside a built canonical image.
- The C++ utilities are not packaged into the image yet.
- Installation, updating, rollback, recovery, and hardware support are not release-verified.

Do not describe a source build, ZIP package, checksum, or workflow definition as a bootable release.
