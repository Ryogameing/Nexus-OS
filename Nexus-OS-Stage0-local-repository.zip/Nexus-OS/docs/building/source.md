# Building the source

Requirements:

- CMake 3.20+
- C++20-compatible compiler
- Bash
- Python 3
- `wget`

Run the complete source gate:

```bash
./scripts/validate-release.sh
```

This builds and tests the development scaffold with warnings as errors, validates metadata and scripts, checks repository hygiene, and smoke-tests the web shell. It does not create an ISO.

For a faster local source build:

```bash
./scripts/build.sh desktop
```
