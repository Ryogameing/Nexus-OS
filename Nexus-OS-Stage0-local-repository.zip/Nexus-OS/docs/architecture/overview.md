# Architecture

NexusOS is organized around small, testable services rather than a monolithic shell.

## Canonical Stage 0 foundation

- `nexus_core`: system metadata and runtime profile selection
- `nexus-shell`: command-line development shell
- `shell/web`: canonical graphical shell source
- `distro/live-build`: the only supported image-construction path
- `distro/profiles`: edition metadata and future package overlays
- `tests`: checks that remain active in Release builds
- `.github/workflows`: pinned continuous integration, ISO, security, and release automation

`VERSION` is the single version source. CMake generates the C++ version header, and the image build generates release JSON for the operating system and web shell.

## Trust boundaries

- CI source validation does not prove an ISO boots.
- A serial boot marker does not prove the graphical session or hardware works.
- The installer and recovery tools remain non-destructive until dedicated safety gates exist.
- The Windows one-click/custom image builders are retired from the canonical release path.

## Next implementation stages

1. Reproducible desktop-amd64 root filesystem and package manifest
2. Real `nexusos-core` Debian package installed into the image
3. BIOS/UEFI boot and graphical-session verification
4. Hardware detection, controllers, audio, graphics, and game launching
5. Installer, signed update, rollback, recovery, and secure release pipeline
