# Nexus Shell

`nexus-shell` is currently a terminal-based development interface. It validates settings, profile selection, library scanning, and mode-selection logic without claiming a production desktop session.

The browser shell in `shell/web` is the canonical graphical source. The ISO build stages that source into `/opt/nexusos/web-shell`; duplicated image copies are not committed.

The current graphical UI uses local release metadata and intentionally disables unavailable launch and installation actions.

## Start

```bash
./build/nexus-shell
```

The shell persists user preferences in `~/.config/nexusos/settings.conf`.

## Safety

The game library scanner inventories launch entries but does not execute them. The installer planner only prints a proposed installation and never partitions or writes to disks.
