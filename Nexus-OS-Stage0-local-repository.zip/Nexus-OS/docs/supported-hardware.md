# Supported hardware

NexusOS does not yet claim production hardware support.

The first verification target is desktop amd64 in QEMU with both BIOS and UEFI firmware. Physical AMD, Intel, NVIDIA, handheld, controller, audio, networking, suspend/resume, and storage support must be added to a public test matrix before being advertised.

arm64 is not an active profile because there is no arm64 kernel, bootloader, package, CI, or hardware pipeline.
