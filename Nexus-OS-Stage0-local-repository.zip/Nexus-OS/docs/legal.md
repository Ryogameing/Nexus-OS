# Legal and redistribution policy

The NexusOS source is MIT-licensed. A built image contains Debian packages, firmware, Steam components, emulators, and other software under their own licenses and terms.

NexusOS source and release artifacts must not include:

- copyrighted game images or ROM sets
- proprietary console BIOS or firmware files
- console encryption keys
- commercial product keys or user credentials
- third-party branding or artwork without redistribution permission

Before a public ISO release, generate a package manifest, software bill of materials, third-party notices, and any required source-offer information.
