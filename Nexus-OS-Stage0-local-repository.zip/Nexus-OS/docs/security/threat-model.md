# Stage 0 threat model

## Protected assets

- user disks and existing operating systems
- user credentials and private game libraries
- release signing identity
- update and package integrity
- CI credentials and GitHub release permissions

## Primary risks

- installer or recovery code targeting the wrong disk
- known default credentials or overbroad administrator access
- compromised build dependencies or mutable CI actions
- untrusted ROM, desktop-entry, script, or package input
- malicious update metadata or rollback failure
- proprietary content entering source or release artifacts

## Stage 0 controls

- installer remains read-only
- known insecure credential patterns are blocked
- tests remain active in Release builds
- GitHub Actions are pinned to immutable commits
- workflows default to read-only permissions
- the release job alone receives content-write permission
- one canonical image pipeline stages source at build time

These controls are a baseline, not a production security review.
