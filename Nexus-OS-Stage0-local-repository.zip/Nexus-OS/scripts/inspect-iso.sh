#!/usr/bin/env bash
set -euo pipefail

ISO="${1:?Usage: $0 path/to/NexusOS.iso}"
EXPECTED_VOLUME="${2:-}"
[[ -f "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 2; }
command -v xorriso >/dev/null || { echo "Missing xorriso" >&2; exit 3; }

REPORT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/nexusos-iso-inspect.XXXXXX")"
trap 'rm -rf "$REPORT_DIR"' EXIT

xorriso -indev "$ISO" -pvd_info >"$REPORT_DIR/pvd.txt" 2>&1
xorriso -indev "$ISO" -find / -type f -print >"$REPORT_DIR/files.txt" 2>&1

if [[ -n "$EXPECTED_VOLUME" ]]; then
  grep -q "$EXPECTED_VOLUME" "$REPORT_DIR/pvd.txt"
fi
grep -Eq '/live/vmlinuz' "$REPORT_DIR/files.txt"
grep -Eq '/live/initrd' "$REPORT_DIR/files.txt"
grep -Eq '/live/filesystem.squashfs' "$REPORT_DIR/files.txt"
grep -Eq '/etc/nexusos/release.json' "$REPORT_DIR/files.txt"
grep -Eq '/opt/nexusos/web-shell/index.html' "$REPORT_DIR/files.txt"
echo "ISO structure and volume label validated"
