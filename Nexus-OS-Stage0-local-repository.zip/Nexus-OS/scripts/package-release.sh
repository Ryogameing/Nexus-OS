#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
OUT="$ROOT/dist"
mkdir -p "$OUT"
ARCHIVE="$OUT/NexusOS-${VERSION}-source.tar.gz"

if git -C "$ROOT" rev-parse --verify HEAD >/dev/null 2>&1; then
  git -C "$ROOT" archive \
    --format=tar \
    --prefix="NexusOS-${VERSION}/" \
    HEAD | gzip -n > "$ARCHIVE"
else
  tar \
    --exclude='./build' \
    --exclude='./dist' \
    --exclude='./distro/live-build/.build' \
    --exclude='.git' \
    -C "$ROOT" \
    -cf - . | gzip -n > "$ARCHIVE"
fi

sha256sum "$ARCHIVE" > "$OUT/SHA256SUMS"
echo "Created $ARCHIVE"
