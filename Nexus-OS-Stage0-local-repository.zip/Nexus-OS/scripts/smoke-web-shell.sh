#!/bin/sh
set -eu

PORT=18765
WORK_DIR=$(mktemp -d "${TMPDIR:-/tmp}/nexusos-web-smoke.XXXXXX")
cp -R shell/web/. "$WORK_DIR/"
./scripts/generate-release-metadata.py "$WORK_DIR/release.json"

python3 scripts/nexus-shell-web.py --root "$WORK_DIR" --port "$PORT" >"$WORK_DIR/server.log" 2>&1 &
PID=$!
trap 'kill "$PID" 2>/dev/null || true; rm -rf "$WORK_DIR"' EXIT

for _attempt in 1 2 3 4 5; do
  if wget -qO "$WORK_DIR/index.response" "http://127.0.0.1:$PORT"; then
    break
  fi
  sleep 1
done

grep -q 'Nebula Ascension' "$WORK_DIR/index.response"
wget -qO- "http://127.0.0.1:$PORT/release.json" | python3 -m json.tool >/dev/null
