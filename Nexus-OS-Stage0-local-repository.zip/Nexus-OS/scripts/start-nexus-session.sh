#!/bin/sh
set -eu

ROOT=${NEXUS_ROOT:-/opt/nexusos}
python3 "$ROOT/scripts/nexus-shell-web.py" --root "$ROOT/web-shell" --port 8765 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null || true' EXIT

ready=0
for _attempt in 1 2 3 4 5; do
  if wget -qO- http://127.0.0.1:8765 >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 1
done
if [ "$ready" -ne 1 ]; then
  echo "Nexus Shell server did not become ready." >&2
  exit 1
fi

if command -v chromium >/dev/null 2>&1; then exec chromium --kiosk --no-first-run http://127.0.0.1:8765
elif command -v xdg-open >/dev/null 2>&1; then xdg-open http://127.0.0.1:8765; wait "$SERVER"
else echo 'Open http://127.0.0.1:8765'; wait "$SERVER"; fi
