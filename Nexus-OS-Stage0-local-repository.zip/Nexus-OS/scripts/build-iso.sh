#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE="${1:-desktop}"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"

case "$PROFILE" in
  desktop) ;;
  handheld|console)
    echo "The $PROFILE profile is scaffolded but not release-supported yet." >&2
    exit 2
    ;;
  *)
    echo "Unsupported ISO profile: $PROFILE" >&2
    exit 2
    ;;
esac

"$ROOT/scripts/preflight-iso.sh"

WORK="$ROOT/distro/live-build/.build/$PROFILE"
case "$WORK" in
  "$ROOT"/distro/live-build/.build/*) ;;
  *) echo "Refusing unsafe build directory: $WORK" >&2; exit 3 ;;
esac

rm -rf "$WORK"
mkdir -p "$WORK" "$ROOT/dist"
cp -a "$ROOT/distro/live-build/auto" "$ROOT/distro/live-build/config" "$WORK/"

IMAGE_ROOT="$WORK/config/includes.chroot"
NEXUS_ROOT="$IMAGE_ROOT/opt/nexusos"
mkdir -p \
  "$IMAGE_ROOT/etc/nexusos" \
  "$NEXUS_ROOT/scripts" \
  "$NEXUS_ROOT/web-shell"

cp "$ROOT/scripts/nexus-shell-web.py" "$NEXUS_ROOT/scripts/"
cp "$ROOT/scripts/start-nexus-session.sh" "$NEXUS_ROOT/scripts/"
cp -a "$ROOT/shell/web/." "$NEXUS_ROOT/web-shell/"
chmod +x "$NEXUS_ROOT/scripts/"*.py "$NEXUS_ROOT/scripts/"*.sh

"$ROOT/scripts/generate-release-metadata.py" \
  --profile "$PROFILE" \
  "$IMAGE_ROOT/etc/nexusos/release.json"
cp "$IMAGE_ROOT/etc/nexusos/release.json" "$NEXUS_ROOT/web-shell/release.json"
printf '%s\n' "$PROFILE" > "$WORK/config/includes.chroot/etc/nexusos/profile"

VOLUME_ID="$(printf 'NEXUSOS_%s' "$VERSION" | tr '[:lower:].-' '[:upper:]__' | tr -cd '[:alnum:]_' | cut -c1-32)"
BUILD=(lb build)
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  command -v sudo >/dev/null || { echo "Run as root or install sudo" >&2; exit 4; }
  BUILD=(sudo lb build)
fi
(
 cd "$WORK"
 ./auto/config \
   --bootappend-live "boot=live components quiet splash nexus.profile=$PROFILE" \
   --iso-volume "$VOLUME_ID"
 "${BUILD[@]}"
)
ISO="$(find "$WORK" -maxdepth 1 -type f \( -name '*.hybrid.iso' -o -name '*.iso' \) -print -quit)"
[[ -n "$ISO" ]] || { echo "ISO build completed without an ISO output" >&2; exit 5; }
OUT="$ROOT/dist/NexusOS-${VERSION}-${PROFILE}-amd64.iso"
cp "$ISO" "$OUT"
sha256sum "$OUT" > "$OUT.sha256"
"$ROOT/scripts/inspect-iso.sh" "$OUT" "$VOLUME_ID"
echo "Created $OUT"
