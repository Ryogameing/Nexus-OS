#!/usr/bin/env bash
set -euo pipefail
required=(lb xorriso debootstrap mksquashfs)
optional=(qemu-system-x86_64)
missing=0
for cmd in "${required[@]}"; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf 'OK       %s -> %s\n' "$cmd" "$(command -v "$cmd")"
  else
    printf 'MISSING  %s\n' "$cmd"
    missing=1
  fi
done
for cmd in "${optional[@]}"; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf 'OK       %s -> %s\n' "$cmd" "$(command -v "$cmd")"
  else
    printf 'OPTIONAL %s (needed for boot smoke tests)\n' "$cmd"
  fi
done
if (( missing )); then
  cat <<'MSG'
Install on Debian/Ubuntu:
  sudo apt-get update
  sudo apt-get install -y live-build xorriso debootstrap squashfs-tools \
    grub-pc-bin grub-efi-amd64-bin mtools
MSG
  exit 3
fi
