#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

for forbidden in build dist work chroot; do
  if git rev-parse --is-inside-work-tree >/dev/null 2>&1 &&
     git ls-files -z | grep -zEq "(^|/)${forbidden}(/|$)"; then
    echo "Tracked generated directory detected: $forbidden" >&2
    exit 1
  fi
done

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git grep -n -E 'nexus:nexus|NOPASSWD:[[:space:]]+ALL' -- \
      . \
      ':!scripts/validate-tree.sh' \
      ':!docs/release/project-history.md'; then
    echo "Known insecure account or sudo configuration detected." >&2
    exit 1
  fi
  if git grep -n -E 'assert[[:space:]]*\(' -- tests; then
    echo "Tests must remain active when NDEBUG is defined." >&2
    exit 1
  fi
else
  if rg -n 'nexus:nexus|NOPASSWD:\s+ALL' . \
      -g '!scripts/validate-tree.sh' \
      -g '!docs/release/project-history.md'; then
    echo "Known insecure account or sudo configuration detected." >&2
    exit 1
  fi
  if rg -n 'assert\s*\(' tests; then
    echo "Tests must remain active when NDEBUG is defined." >&2
    exit 1
  fi
fi

if rg -n 'uses:\s*[^#[:space:]]+@(v[0-9]+|main|master)\b' .github/workflows; then
  echo "GitHub Actions must be pinned to immutable commit SHAs." >&2
  exit 1
fi

echo "Repository security and hygiene checks passed"
