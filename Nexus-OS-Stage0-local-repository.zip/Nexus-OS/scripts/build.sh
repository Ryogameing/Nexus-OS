#!/usr/bin/env bash
set -euo pipefail

PROFILE="${1:-desktop}"
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/nexus-shell "$PROFILE"
