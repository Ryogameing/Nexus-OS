#!/usr/bin/env bash
set -euo pipefail

ISO="${1:?Usage: $0 path/to/NexusOS.iso [bios|uefi]}"
MODE="${2:-bios}"
[[ -f "$ISO" ]] || { echo "ISO not found: $ISO" >&2; exit 2; }
command -v qemu-system-x86_64 >/dev/null || { echo "Missing qemu-system-x86_64" >&2; exit 3; }
case "$MODE" in bios|uefi) ;; *) echo "Unsupported QEMU mode: $MODE" >&2; exit 4;; esac

TIMEOUT="${NEXUS_QEMU_TIMEOUT:-180}"
LOG="${ISO}.${MODE}.qemu.log"
QEMU_ARGS=(
  -machine accel=tcg
  -m 2048
  -smp 2
  -boot d
  -cdrom "$ISO"
  -display none
  -serial stdio
  -no-reboot
)

if [[ "$MODE" == "uefi" ]]; then
  OVMF=""
  for candidate in \
    /usr/share/OVMF/OVMF_CODE.fd \
    /usr/share/OVMF/OVMF_CODE_4M.fd \
    /usr/share/ovmf/OVMF.fd; do
    if [[ -f "$candidate" ]]; then
      OVMF="$candidate"
      break
    fi
  done
  [[ -n "$OVMF" ]] || { echo "OVMF firmware not found. Install ovmf." >&2; exit 5; }
  QEMU_ARGS=(-bios "$OVMF" "${QEMU_ARGS[@]}")
fi

set +e
timeout "$TIMEOUT" qemu-system-x86_64 "${QEMU_ARGS[@]}" >"$LOG" 2>&1
status=$?
set -e
if grep -q 'NEXUSOS_BOOT_OK' "$LOG"; then echo "QEMU $MODE boot marker detected"; exit 0; fi
if grep -Eiq 'Kernel panic|not syncing|No bootable device|Boot failed' "$LOG"; then echo "QEMU boot failure detected. See $LOG" >&2; exit 1; fi
echo "QEMU exited with status $status; boot marker not detected. See $LOG" >&2
exit 1
