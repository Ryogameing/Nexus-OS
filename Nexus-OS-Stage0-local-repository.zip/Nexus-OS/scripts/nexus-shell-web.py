#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import argparse

p=argparse.ArgumentParser(); p.add_argument('--port',type=int,default=8765); p.add_argument('--root',default=str(Path(__file__).resolve().parents[1]/'shell'/'web')); a=p.parse_args()
print(f'Nexus Shell running at http://127.0.0.1:{a.port}')
handler = partial(SimpleHTTPRequestHandler, directory=a.root)
ThreadingHTTPServer(('127.0.0.1',a.port),handler).serve_forever()
