#!/usr/bin/env python3
"""Generate release metadata from the repository's canonical VERSION file."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
VERSION_PATTERN = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-.][0-9A-Za-z.-]+)?$")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--profile", default="desktop")
    args = parser.parse_args()

    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    if not VERSION_PATTERN.fullmatch(version):
        raise SystemExit(f"Unsupported VERSION value: {version}")

    channel = "stable"
    if "alpha" in version:
        channel = "alpha"
    elif "beta" in version:
        channel = "beta"
    elif "rc" in version:
        channel = "release-candidate"
    elif "dev" in version:
        channel = "development"

    metadata = {
        "name": "NexusOS",
        "version": version,
        "codename": "Nebula Ascension",
        "channel": channel,
        "profile": args.profile,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
