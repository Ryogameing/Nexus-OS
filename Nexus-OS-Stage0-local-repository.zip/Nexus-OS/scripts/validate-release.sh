#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

"$ROOT/scripts/validate-tree.sh"

cmake -S "$ROOT" -B "$ROOT/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DNEXUS_WARNINGS_AS_ERRORS=ON
cmake --build "$ROOT/build" --parallel
ctest --test-dir "$ROOT/build" --output-on-failure

for file in "$ROOT"/distro/profiles/*.json; do
  python3 -m json.tool "$file" >/dev/null
done

while IFS= read -r -d '' file; do
  bash -n "$file"
done < <(find "$ROOT/scripts" "$ROOT/installer" "$ROOT/recovery" "$ROOT/distro/live-build" \
  -type f \( -name '*.sh' -o -name '*.hook.chroot' -o -path '*/auto/config' \) -print0)

PYTHONPYCACHEPREFIX="${TMPDIR:-/tmp}/nexusos-pycache" \
  python3 -m py_compile \
    "$ROOT/scripts/nexus-shell-web.py" \
    "$ROOT/scripts/generate-release-metadata.py"

METADATA="$(mktemp "${TMPDIR:-/tmp}/nexusos-release.XXXXXX.json")"
trap 'rm -f "$METADATA"' EXIT
"$ROOT/scripts/generate-release-metadata.py" "$METADATA"
python3 -m json.tool "$METADATA" >/dev/null
python3 - "$ROOT/VERSION" "$METADATA" <<'PY'
import json
from pathlib import Path
import sys

version = Path(sys.argv[1]).read_text(encoding="utf-8").strip()
metadata = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
if metadata["version"] != version:
    raise SystemExit("Generated release metadata does not match VERSION")
PY

"$ROOT/scripts/smoke-web-shell.sh"
echo "NexusOS source validation passed"
