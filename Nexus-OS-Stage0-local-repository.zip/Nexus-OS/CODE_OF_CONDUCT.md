# Community code of conduct

NexusOS contributors and maintainers are expected to communicate respectfully, accept constructive technical feedback, and keep collaboration free from harassment or discrimination.

Project spaces may not be used to exchange copyrighted games, console BIOS files, product keys, credentials, malware, or instructions intended to bypass platform security.

Maintainers may edit or remove content and restrict participation when necessary to protect contributors, users, or the project. Report conduct concerns privately to the repository owner.
